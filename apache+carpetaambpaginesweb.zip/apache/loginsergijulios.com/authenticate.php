<?php
// LDAP server settings
$ldap_host = 'ldap://192.168.12.1'; // Cambia esto por la dirección de tu servidor LDAP
$ldap_port = 389; // Cambia esto por el puerto de tu servidor LDAP
$ldap_base_dn = 'dc=ldapsj,dc=com'; // Cambia esto por el base DN de tu LDAP
$ldap_user_suffix = '@ldapsj.com'; // Cambia esto por el sufijo de usuario de tu LDAP

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form inputs
    $username = $_POST['username'];
    $password = $_POST['password'];

    // LDAP connection
    $ldap_conn = ldap_connect($ldap_host, $ldap_port);

    if ($ldap_conn) {
        // Set LDAP options
        ldap_set_option($ldap_conn, LDAP_OPT_PROTOCOL_VERSION, 3);
        ldap_set_option($ldap_conn, LDAP_OPT_REFERRALS, 0);
        ldap_set_option($ldap_conn, LDAP_OPT_DEBUG_LEVEL, 7);

        // Bind to LDAP server
        $ldap_bind = @ldap_bind($ldap_conn, 'cn=' . $username . ',' . $ldap_base_dn, $password);

        if ($ldap_bind) {
            // User authenticated
            header("Location: redireccio.html");
            exit();
            // Puedes realizar acciones adicionales aquí, como recuperar información del usuario de LDAP
        } else {
            // Authentication failed
            echo "Invalid username or password.";
            echo "LDAP bind failed: " . ldap_error($ldap_conn);
        }
    } else {
        // LDAP connection failed
        echo "Failed to connect to LDAP server.";
    }

    // Close LDAP connection
    ldap_close($ldap_conn);
}
?>
